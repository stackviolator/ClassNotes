public class User extends CanvasHandler {
    private String name;
    private String password;
}
