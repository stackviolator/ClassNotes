public class Professor extends User {
    private String name;
    private String email;
    private String assignment;
    private String lesson;
    private String dueDate;

    public void readEmails() {
    }
    public void createAssignment() {
    }
    public void updateExtension() {
    }
}
