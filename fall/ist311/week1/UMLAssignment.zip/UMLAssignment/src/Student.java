public class Student extends User {
    private String name;
    private Professor professor;
    private String email;
    private String Assignment;

    public void emailProfessor() {
    }

    public void requestExtension() {
    }

    public void createTodoListP() {
    }
}
