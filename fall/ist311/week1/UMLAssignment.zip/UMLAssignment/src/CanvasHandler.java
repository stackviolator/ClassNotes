import java.io.File;

public class CanvasHandler {
    private User user;
    private String course;
    private File file;
    private String recipient;


    public void parseEmails() {
    }
    public void exportDueDates() {
    }
    public void sendDueDates() {
    }
}
e