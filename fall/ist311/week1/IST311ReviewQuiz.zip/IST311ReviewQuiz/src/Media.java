import java.util.ArrayList;

public abstract class Media {
    String title;
    private String subtitle;
    int numCopies;
    private float idNumber;
    ArrayList<String> heldBy;

    public Media(String title, String subtitle, int numCopies, float idNumber) {
        this.title = title;
        this.subtitle = subtitle;
        this.numCopies = numCopies;
        this.idNumber = idNumber;
        this.heldBy = new ArrayList<String>();
    }

    public abstract boolean checkOut(String name);
    public abstract boolean checkIn(String name);
}
