public class Book extends Media {
    String author;


    public Book(String author, String title, String subtitle, int numCopies, float idNumber) {
        super(title, subtitle, numCopies, idNumber);
        this.author = author;
    }

    @Override
    public boolean checkOut(String name) {
        System.out.printf("%s is checking out %s, by %s\n", name, super.title, this.author);
        if (super.numCopies > super.heldBy.size()) {
            super.heldBy.add(name);
            return true;
        }
        return false;
    }

    @Override
    public boolean checkIn(String name) {
        System.out.printf("%s checking in %s\n", name, super.title);
        if (super.heldBy.contains(name)) {
            super.heldBy.remove(name);
            return true;
        }
        return false;
    }
}
