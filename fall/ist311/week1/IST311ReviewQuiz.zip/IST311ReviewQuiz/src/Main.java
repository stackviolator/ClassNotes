public class Main {
    public static void main(String[] args) {
        boolean test;
        Book dune = new Book("Frank Herbert", "Dune", "A subtitle", 3, 100);
        Book lotr = new Book("JRR Tolkien", "Lord of The Rings", "The Fellowship of the Ring", 1, 101);

        /*
        Call checkout on the first book with name = "Mark Twain"
        Call checkout on the first book with name = "Charles Dickens"
        Ensure that both of these return true (you can simply print the result)
         */
        test = dune.checkOut("Mark Twain");
        System.out.println(test);
        test = dune.checkOut("Charles Dickens");
        System.out.println(test);

        /*
        Call checkin on the first book with name = "Mark Twain"
        Call checkin on the first book with name = "Samuel Clemens"
        Ensure that the first result is true and the second is false
         */
        test = dune.checkIn("Mark Twain");
        System.out.println(test);
        test = dune.checkIn("Samuel Clemens");
        System.out.println(test);

        /*
        Call checkout on the second book with name = "Mark Twain"
        Call checkout on the second book with name = "Charles Dickens"
        Ensure that the first result is true and the second is false
         */
        test = lotr.checkOut("Mark Twain");
        System.out.println(test);
        test = lotr.checkOut("Charles Dickens");
        System.out.println(test);

        /*
        Call checkin on the second book with name = "Mark Twain"
        Call checkout on the second book with name = "Charles Dickens"
        Ensure that both of these return true
         */
        test = lotr.checkIn("Mark Twain");
        System.out.println(test);
        test = lotr.checkOut("Charles Dickens");
        System.out.println(test);
    }
}
